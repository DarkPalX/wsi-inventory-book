<?php $__env->startSection('pagetitle'); ?>
    Manage Menus
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagecss'); ?>
	<link href="<?php echo e(asset('lib/bselect/dist/css/bootstrap-select.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/ion-rangeslider/css/ion.rangeSlider.min.css')); ?>" rel="stylesheet">
    <style>
        .row-selected {
            background-color: #92b7da !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-style1 mg-b-5">
                    <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('dashboard')); ?>">CMS</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Menu</li>
                </ol>
            </nav>
            <h4 class="mg-b-0 tx-spacing--1">Manage Menus</h4>
        </div>
    </div>

    <div class="row row-sm">
        <div class="col-md-12">
            <div class="filter-buttons mg-b-10">
                <div class="d-md-flex bd-highlight">
                    <div class="bd-highlight mg-r-10 mg-t-10">
                        <div class="dropdown d-inline mg-r-5">
                            <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php echo e(__('common.filters')); ?>

                            </button>
                            <div class="dropdown-menu">
                                <form id="filterForm" class="pd-20">
                                    <div class="form-group">
                                        <label for="exampleDropdownFormEmail1"><?php echo e(__('common.sort_by')); ?></label>
                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="orderBy1" name="orderBy" class="custom-control-input" value="updated_at" <?php if($filter->orderBy == 'updated_at'): ?> checked <?php endif; ?>>
                                            <label class="custom-control-label" for="orderBy1"><?php echo e(__('common.date_modified')); ?></label>
                                        </div>
                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="orderBy2" name="orderBy" class="custom-control-input" value="name" <?php if($filter->orderBy == 'name'): ?> checked <?php endif; ?>>
                                            <label class="custom-control-label" for="orderBy2"><?php echo e(__('common.name')); ?></label>
                                        </div>
                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="orderBy3" name="orderBy" class="custom-control-input" value="is_active" <?php if($filter->orderBy == 'is_active'): ?> checked <?php endif; ?>>
                                            <label class="custom-control-label" for="orderBy3"><?php echo e(__('common.status')); ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleDropdownFormEmail1"><?php echo e(__('common.sort_order')); ?></label>
                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="sortByAsc" name="sortBy" class="custom-control-input" value="asc" <?php if($filter->sortBy == 'asc'): ?> checked <?php endif; ?>>
                                            <label class="custom-control-label" for="sortByAsc"><?php echo e(__('common.ascending')); ?></label>
                                        </div>

                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="sortByDesc" name="sortBy" class="custom-control-input" value="desc"  <?php if($filter->sortBy == 'desc'): ?> checked <?php endif; ?>>
                                            <label class="custom-control-label" for="sortByDesc"><?php echo e(__('common.descending')); ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" id="showDeleted" name="showDeleted" class="custom-control-input" <?php if($filter->showDeleted): ?> checked <?php endif; ?>>
                                            <label class="custom-control-label" for="showDeleted"><?php echo e(__('common.show_deleted')); ?></label>
                                        </div>
                                    </div>
                                    <div class="form-group mg-b-40">
                                        <label class="d-block"><?php echo e(__('common.item_displayed')); ?></label>
                                        <input id="displaySize" type="text" class="js-range-slider" name="perPage" value="<?php echo e($filter->perPage); ?>"/>
                                    </div>
                                    <button id="filter" type="button" class="btn btn-sm btn-primary"><?php echo e(__('common.apply_filters')); ?></button>
                                </form>
                            </div>
                        </div>
                        <?php if(auth()->user()->has_access_to_route('menus.destroy_many')): ?>
                            <div class="list-search d-inline">
                                <div class="dropdown d-inline mg-r-10">
                                    <button class="btn btn-light btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Actions
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <button id="deleteMenus" class="dropdown-item tx-danger">Delete</button>
                                        <form id="menusForm" method="POST" action="<?php echo e(route('menus.destroy_many')); ?>">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <input name="ids" id="menuIds" type="hidden">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="ml-auto bd-highlight mg-t-10">
                        <form class="form-inline" id="searchForm">
                            <div class="search-form mg-r-10">
                                <input name="search" type="search" id="search" class="form-control" placeholder="Search by Name" value="<?php echo e($filter->search); ?>">
                                <button class="btn"><i data-feather="search"></i></button>
                            </div>
                            <?php if(auth()->user()->has_access_to_route('menus.create')): ?>
                                <a href="<?php echo e(route('menus.create')); ?>" class="btn btn-primary btn-sm mg-b-5 mt-lg-0 mt-md-0 mt-sm-0 mt-1">Create a Menu</a>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12">
            <div class="table-list mg-b-10">
                <div class="table-responsive-lg">
                    <table class="table mg-b-0 table-light table-hover" style="table-layout: fixed;word-wrap: break-word;">
                        <thead>
                            <tr>
                                <th>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="checkbox_all">
                                        <label class="custom-control-label" for="checkbox_all"></label>
                                    </div>
                                </th>
                                <th scope="col" class="wd-35p-f we-lg-50p-f">Menu Name</th>
                                <th scope="col">Menu Status</th>
                                <th scope="col">Date Modified</th>
                                <th scope="col" class="text-right">Options</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr id="row<?php echo e($menu->id); ?>" class="<?php if(!$menu->is_active): ?> row_cb <?php endif; ?>">
                                    <th>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input <?php if(!$menu->is_active): ?> cb  <?php endif; ?>" id="cb<?php echo e($menu->id); ?>" data-id="<?php echo e($menu->id); ?>" data-is-active="<?php echo e($menu->is_active); ?>" <?php if($menu->is_active): ?> disabled <?php endif; ?>>
                                            <label class="custom-control-label" for="cb<?php echo e($menu->id); ?>"></label>
                                        </div>
                                    </th>
                                    <td style="overflow: hidden;text-overflow: ellipsis;">
                                        <strong <?php if($menu->trashed()): ?> style="text-decoration:line-through;" <?php endif; ?> title="<?php echo e($menu->name); ?>"><?php echo e($menu->name); ?></strong><br />
                                        <p class="mg-b-0 tx-gray-500 tx-11" style="overflow: hidden;text-overflow: ellipsis;">
                                            <?php $__currentLoopData = $menu->navigation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($link->page_id == 0): ?>
                                                    <?php echo e($link->label); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo e($link->page->name); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </p>
                                    </td>
                                    <td>
                                        <?php if($menu->is_active): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="text-nowrap"><?php echo e(SettingHelper::date_for_listing($menu->updated_at)); ?></span>
                                    </td>
                                    <td>
                                        <?php if($menu->trashed()): ?>
                                            <?php if(auth()->user()->has_access_to_route('menus.restore')): ?>
                                                <nav class="nav table-options justify-content-end">
                                                    <a class="nav-link" href="<?php echo e(route('menus.restore', $menu->id)); ?>" title="Restore this menu"><i data-feather="rotate-ccw"></i></a>
                                                </nav>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <nav class="nav table-options justify-content-end">
                                                <?php if(auth()->user()->has_access_to_route('menus.edit')): ?>
                                                    <a class="nav-link" title="Edit menu" href="<?php echo e(route('menus.edit', $menu->id)); ?>">
                                                        <i data-feather="edit"></i>
                                                    </a>
                                                <?php endif; ?>

                                                <?php if(auth()->user()->has_access_to_route('menus.edit') || auth()->user()->has_access_to_route('menus.destroy')): ?>
                                                    <a class="nav-link" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i data-feather="settings"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <?php if(auth()->user()->has_access_to_route('menus.edit')): ?>
                                                            <a class="dropdown-item" data-target="#promptQuickEdit" data-toggle="modal" data-animation="effect-scale" data-id="<?php echo e($menu->id); ?>" data-name="<?php echo e($menu->name); ?>" data-is-active="<?php echo e($menu->is_active); ?>">Quick Edit</a>
                                                        <?php endif; ?>

                                                        <?php if(auth()->user()->has_access_to_route('menus.destroy')): ?>
                                                            <button type="button" class="dropdown-item" <?php if($menu->is_active): ?> disabled <?php endif; ?> data-target="#prompt-delete-menu" data-toggle="modal" data-animation="effect-scale" data-id="<?php echo e($menu->id); ?>" data-name="<?php echo e($menu->name); ?>" data-is-active="<?php echo e($menu->is_active); ?>">Delete</button>
                                                            <?php if(!$menu->is_active): ?>
                                                                <form id="menuForm<?php echo e($menu->id); ?>" method="POST" action="<?php echo e(route('menus.destroy', $menu->id)); ?>">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('DELETE'); ?>
                                                                </form>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </nav>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <th colspan="5" style="text-align: center;"> <p class="text-danger">No menus found</p></th>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <!-- table-responsive -->
            </div>
        </div>
        <div class="col-md-6">
            <div class="mg-t-5">
                <?php if($menus->firstItem() == null): ?>
                    <p class="tx-gray-400 tx-12 d-inline"><?php echo e(__('common.showing_zero_items')); ?></p>
                <?php else: ?>
                    <p class="tx-gray-400 tx-12 d-inline">Showing <?php echo e($menus->firstItem()); ?> to <?php echo e($menus->lastItem()); ?> of <?php echo e($menus->total()); ?> items</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-md-right float-md-right mg-t-5">
                <div>
                    <?php echo e($menus->appends((array) $filter)->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal effect-scale" id="prompt-delete-menu" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('common.delete_confirmation_title')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p><?php echo e(__('common.delete_confirmation')); ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-danger" id="deleteMenu">Yes, Delete</button>
                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<div class="modal effect-scale" id="delete-active-menu" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Error</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Please set a different menu to active before deleting this menu.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<div class="modal effect-scale" id="prompt-delete-many" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('common.delete_mutiple_confirmation_title')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p><?php echo e(__('common.delete_mutiple_confirmation')); ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-danger" id="btnDeleteMany">Yes, Delete</button>
                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<div class="modal effect-scale" id="promptQuickEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Quick Edit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="editForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label class="d-block">Menu Name *</label>
                        <input type="text" class="form-control" name="name" id="editName">
                    </div>
                    <div class="form-group">
                        <div class="custom-control custom-switch">
                            <input type="hidden" required name="is_active" id="menuIsActive">
                            <input type="hidden" required name="pages_json" id="menuIsActive" value="[]">
                            <input type="checkbox" class="custom-control-input" id="editStatus">
                            <label class="custom-control-label" for="editStatus" id="editLabelStatus">Inactive</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-sm btn-primary">Save Menu</button>
                        <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal effect-scale" id="prompt-no-selected" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('common.no_selected_title')); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p><?php echo e(__('common.no_selected')); ?></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagejs'); ?>
	<script src="<?php echo e(asset('lib/bselect/dist/js/bootstrap-select.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/bselect/dist/js/i18n/defaults-en_US.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/ion-rangeslider/js/ion.rangeSlider.min.js')); ?>"></script>
    <script>
        let listingUrl = "<?php echo e(route('menus.index')); ?>";
        let advanceListingUrl = "";
        let searchType = "<?php echo e($searchType); ?>";
    </script>
    <script src="<?php echo e(asset('js/listing.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
    <?php if($errors->any()): ?>
        <script>
            $('#toastErrorMessage').toast('show');
        </script>
    <?php endif; ?>

    <script>
        function checkStatus($status) {
            if ($status) {
                $('#editStatus').prop('checked', true);
                $('#editLabelStatus').html('Active');
                $('#menuIsActive').val(1);
            } else {
                $('#editStatus').prop('checked', false);
                $('#editLabelStatus').html('Inactive');
                $('#menuIsActive').val(0);
            }
        }

        $('#promptQuickEdit').on('show.bs.modal', function (e) {
            //get data-id attribute of the clicked element

            let menu = e.relatedTarget;
            let menuId = $(menu).data('id');
            let menuName = $(menu).data('name');
            let menuIsActive = $(menu).data('is-active');
            let formAction = "<?php echo e(route('menus.quick_update', 0)); ?>".split('/');
            formAction.pop();
            let editFormAction = formAction.join('/') + "/" + menuId;
            $('#editForm').attr('action', editFormAction);

            $('#editName').val(menuName);
            checkStatus(menuIsActive);

            if (menuIsActive) {
                $('#editStatus').prop('disabled', true);
            } else {
                $('#editStatus').prop('disabled', false);
            }
        });

        $('#editStatus').on('click', function() {
            checkStatus($(this).is(':checked'));
        });

        let ids;
        $('#deleteMenus').on('click', function() {
            if($(".cb:checked").length <= 0){
                $('#prompt-no-selected').modal('show');
                return false;
            }
            else {
                ids = [];
                $.each($(".cb:checked"), function() {
                    ids.push($(this).data('id'));
                });

                $('#prompt-delete-many').modal('show');
            }
        });

        $('#btnDeleteMany').on('click', function () {
            $('#menuIds').val(ids);
            $('#menusForm').submit();
        });

        let aid;
        $('#prompt-delete-menu').on('show.bs.modal', function (e) {
            let menu = e.relatedTarget;
            aid = $(menu).data('id');
        });

        $('#deleteMenu').on('click', function() {
            $('#menuForm'+aid).submit();
            $('#prompt-delete-menu').modal('hide');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/admin/cms4/menu/index.blade.php ENDPATH**/ ?>