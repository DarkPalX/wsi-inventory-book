@extends('admin.layouts.app')

@section('pagetitle')
    Member Management
@endsection

@section('pagecss')
    <link href="{{ asset('lib/bselect/dist/css/bootstrap-select.css') }}" rel="stylesheet">
@endsection

@section('content')
<div class="container pd-x-0">
    <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
        <div>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-style1 mg-b-10">
                    <li class="breadcrumb-item" aria-current="page"><a href="{{route('dashboard')}}">CMS</a></li>
                    <li class="breadcrumb-item" aria-current="page"><a href="{{route('members.index')}}">Members</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Edit a Member</li>
                </ol>
            </nav>
            <h4 class="mg-b-0 tx-spacing--1">Edit a Member</li>
        </div>
    </div>

    <div class="row row-sm">
        <div class="col-lg-6">
            <form action="{{ route('members.update', $member->id) }}" method="post">
                @csrf
                <input type="text" name="id" value="{{ $member->id }}" hidden>
                <div class="form-group">
                    <label class="d-block">Fullname *</label>
                    <input type="text" name="name" id="name" value="{{ old('name', $member->name)}}" class="form-control @error('name') is-invalid @enderror" required>
                    @error('name')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <div class="form-group">
                    <label class="d-block">Email *</label>
                    <input type="email" name="email" id="email" value="{{ old('email', $member->email) }}" class="form-control @error('email') is-invalid @enderror" required>
                    @error('email')
                        <span class="text-danger">{{ $message }}</span>
                    @enderror
                </div>
                <button class="btn btn-primary btn-sm btn-uppercase" type="submit">Update Member</button>
                <a class="btn btn-outline-secondary btn-sm btn-uppercase" href="{{ route('members.index') }}">Cancel</a>
            </form>
        </div>
    </div>
</div>
@endsection

@section('pagejs')
    <script src="{{ asset('lib/bselect/dist/js/bootstrap-select.js') }}"></script>
@endsection

@section('customjs')
    <script>
        $(function() {
            $('.selectpicker').selectpicker();
        });
    </script>
@endsection
