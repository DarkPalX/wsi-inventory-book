<?php $__env->startSection('pagetitle'); ?>
    Manage Banners
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagecss'); ?>
    <link href="<?php echo e(asset('lib/bselect/dist/css/bootstrap-select.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/ion-rangeslider/css/ion.rangeSlider.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/owl.carousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/owl.carousel/assets/owl.theme.default.min.css')); ?>" rel="stylesheet">
    <style>
        .row-selected {
            background-color: #92b7da !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container pd-x-0">
        <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
            <div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb breadcrumb-style1 mg-b-5">
                        <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('dashboard')); ?>">CMS</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Albums</li>
                    </ol>
                </nav>
                <h4 class="mg-b-0 tx-spacing--1">Manage Albums</h4>
            </div>
        </div>

        <div class="row row-sm">
            <div class="col-md-12">
                <div class="filter-buttons mg-b-10">
                    <div class="d-md-flex bd-highlight">
                        <div class="bd-highlight mg-r-10 mg-t-10">
                            <div class="dropdown d-inline mg-r-5">
                                <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Filters
                                </button>
                                <div class="dropdown-menu">
                                    <form id="filterForm" class="pd-20">
                                        <div class="form-group">
                                            <label for="exampleDropdownFormEmail1"><?php echo e(__('common.sort_by')); ?></label>
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="orderBy1" name="orderBy" class="custom-control-input" value="updated_at" <?php if($filter->orderBy == 'updated_at'): ?> checked <?php endif; ?>>
                                                <label class="custom-control-label" for="orderBy1"><?php echo e(__('common.date_modified')); ?></label>
                                            </div>
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="orderBy2" name="orderBy" class="custom-control-input" value="name" <?php if($filter->orderBy == 'name'): ?> checked <?php endif; ?>>
                                                <label class="custom-control-label" for="orderBy2"><?php echo e(__('common.name')); ?></label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleDropdownFormEmail1"><?php echo e(__('common.sort_order')); ?></label>
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="sortByAsc" name="sortBy" class="custom-control-input" value="asc" <?php if($filter->sortBy == 'asc'): ?> checked <?php endif; ?>>
                                                <label class="custom-control-label" for="sortByAsc"><?php echo e(__('common.ascending')); ?></label>
                                            </div>

                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="sortByDesc" name="sortBy" class="custom-control-input" value="desc"  <?php if($filter->sortBy == 'desc'): ?> checked <?php endif; ?>>
                                                <label class="custom-control-label" for="sortByDesc"><?php echo e(__('common.descending')); ?></label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" id="showDeleted" name="showDeleted" class="custom-control-input" <?php if($filter->showDeleted): ?> checked <?php endif; ?>>
                                                <label class="custom-control-label" for="showDeleted"><?php echo e(__('common.show_deleted')); ?></label>
                                            </div>
                                        </div>
                                        <div class="form-group mg-b-40">
                                            <label class="d-block"><?php echo e(__('common.item_displayed')); ?></label>
                                            <input id="displaySize" type="text" class="js-range-slider" name="perPage" value="<?php echo e($filter->perPage); ?>"/>
                                        </div>
                                        <button id="filter" type="button" class="btn btn-sm btn-primary"><?php echo e(__('common.apply_filters')); ?></button>
                                    </form>
                                </div>
                            </div>
                            <?php if(auth()->user()->has_access_to_route('albums.destroy_many')): ?>
                                <div class="list-search d-inline">
                                    <div class="dropdown d-inline mg-r-10">
                                        <button class="btn btn-light btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            Actions
                                        </button>
                                        <form id="albumsForm" method="POST" class="d-none" action="<?php echo e(route('albums.destroy_many')); ?>">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <input name="ids" id="albumIds" type="hidden">
                                        </form>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <button id="deleteAlbums" class="dropdown-item tx-danger">Delete</button>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="ml-auto bd-highlight mg-t-10">
                            <form class="form-inline" id="searchForm">
                                <div class="search-form mg-r-10">
                                    <input name="search" type="search" id="search" class="form-control" placeholder="Search by Name" value="<?php echo e($filter->search); ?>">
                                    <button class="btn"><i data-feather="search"></i></button>
                                </div>
                                <?php if(auth()->user()->has_access_to_route('albums.edit')): ?>
                                    <a href="<?php echo e(route('albums.edit', 1)); ?>" class="btn btn-primary btn-sm mg-b-5 mt-lg-0 mt-md-0 mt-sm-0 mt-1">Manage Home Banner</a>
                                <?php endif; ?>
                                <?php if(auth()->user()->has_access_to_route('albums.create')): ?>
                                    <a href="<?php echo e(route('albums.create')); ?>" class="btn btn-primary btn-sm mg-b-5 mg-l-5 mt-lg-0 mt-md-0 mt-sm-0 mt-1">Create an Album</a>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="table-list mg-b-10">
                    <div class="table-responsive-lg">
                        <table class="table mg-b-0 table-light table-hover" style="width:100%;word-wrap: break-word;">
                            <thead>
                            <tr>
                                <th>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="checkbox_all">
                                        <label class="custom-control-label" for="checkbox_all"></label>
                                    </div>
                                </th>
                                <th scope="col" width="60%">Album Name</th>
                                <th scope="col">Total images</th>
                                <th scope="col">Date Updated</th>
                                <th scope="col" class="text-right">Options</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr id="row<?php echo e($album->id); ?>" class="row_cb">
                                    <th>
                                        <div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input cb" id="cb<?php echo e($album->id); ?>" data-id="<?php echo e($album->id); ?>">
                                            <label class="custom-control-label" for="cb<?php echo e($album->id); ?>"></label>
                                        </div>
                                    </th>
                                    <td style="overflow: hidden;text-overflow: ellipsis;" title="<?php echo e($album->name); ?>">
                                        <strong <?php if($album->trashed()): ?> style="text-decoration:line-through;" <?php endif; ?> title="<?php echo e($album->name); ?>"><?php echo e($album->name); ?></strong>
                                    </td>
                                    <td><?php echo e($album->banners->count()); ?></td>
                                    <td><span class="text-nowrap"><?php echo e(Setting::date_for_listing($album->updated_at)); ?></span></td>
                                    <td>
                                        <?php if($album->trashed()): ?>
                                            <?php if(auth()->user()->has_access_to_route('albums.restore')): ?>
                                                <nav class="nav table-options justify-content-end flex-nowrap">
                                                    <form id="form<?php echo e($album->id); ?>" method="post" action="<?php echo e(route('albums.restore', $album->id)); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('POST'); ?>
                                                        <a class="nav-link" href="#" title="Restore this banner" onclick="document.getElementById('form<?php echo e($album->id); ?>').submit()"><i data-feather="rotate-ccw"></i></a>
                                                    </form>
                                                </nav>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <nav class="nav table-options justify-content-end flex-nowrap">
                                                <?php if(auth()->user()->has_access_to_route('albums.edit')): ?>
                                                    <a class="nav-link" title="Edit banner" href="<?php echo e(route('albums.edit', $album->id)); ?>"><i data-feather="edit"></i></a>
                                                <?php endif; ?>

                                                <?php if(auth()->user()->has_access_to_route('albums.quick_update') || auth()->user()->has_access_to_route('albums.destroy')): ?>
                                                    <a class="nav-link" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i data-feather="settings"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right">
                                                        <?php if(auth()->user()->has_access_to_route('albums.quick_update')): ?>
                                                            <a class="dropdown-item" data-toggle="modal" data-target="#promptQuickEdit" href="#" data-id="<?php echo e($album->id); ?>" data-name="<?php echo e($album->name); ?>" data-transition-in="<?php echo e($album->transition_in); ?>" data-transition-out="<?php echo e($album->transition_out); ?>" data-transition="<?php echo e($album->transition); ?>">Quick Edit</a>
                                                        <?php endif; ?>
                                                        <?php if(auth()->user()->has_access_to_route('albums.destroy')): ?>
                                                            <button type="button" class="dropdown-item" data-target="#prompt-delete" data-toggle="modal" data-animation="effect-scale" data-id="<?php echo e($album->id); ?>" data-name="<?php echo e($album->name); ?>">Delete</button>
                                                            <form id="albumForm<?php echo e($album->id); ?>" method="POST" action="<?php echo e(route('albums.destroy', $album->id)); ?>" class="d-none">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('DELETE'); ?>
                                                            </form>
                                                        <?php endif; ?>
                                                    </div>
                                                <?php endif; ?>
                                            </nav>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" style="text-align: center;"> <p class="text-danger">No albums found.</p></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- table-responsive -->
                </div>
            </div>
            <div class="col-md-6">
                <div class="mg-t-5">
                    <?php if($albums->firstItem() == null): ?>
                        <p class="tx-gray-400 tx-12 d-inline"><?php echo e(__('common.showing_zero_items')); ?></p>
                    <?php else: ?>
                        <p class="tx-gray-400 tx-12 d-inline">Showing <?php echo e($albums->firstItem()); ?> to <?php echo e($albums->lastItem()); ?> of <?php echo e($albums->total()); ?> items</p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="text-md-right float-md-right mg-t-5">
                    <div>
                        <?php echo e($albums->appends((array) $filter)->links()); ?>

                    </div>
                </div>
            </div>

        </div>
    </div>
    <?php if(auth()->user()->has_access_to_route('albums.quick_update')): ?>
        <div class="modal effect-scale" id="promptQuickEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalCenterTitle">Quick Edit Banner</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form id="editForm" method="POST" action="">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label class="d-block">Album Name *</label>
                                <input type="text" class="form-control" name="name" id="editName" required>
                            </div>
                            <div class="form-group">
                                <label class="d-block">Transition In *</label>
                                <select name="transition_in" id="editTransitionIn" class="selectpicker mg-b-5" data-style="btn btn-outline-light btn-sm btn-block tx-left" title="Select transition" data-width="100%" required>
                                    <?php $__currentLoopData = $animations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($animation->is_entrance_field_type()): ?>
                                            <option value="<?php echo e($animation->id); ?>"><?php echo e($animation->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="d-block">Transition Out *</label>
                                <select name="transition_out" id="editTransitionOut" class="selectpicker mg-b-5" data-style="btn btn-outline-light btn-sm btn-block tx-left" title="Select transition" data-width="100%" required>
                                    <?php $__currentLoopData = $animations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($animation->is_exit_field_type()): ?>
                                            <option value="<?php echo e($animation->id); ?>"><?php echo e($animation->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="d-block">Transition Duration (seconds) *</label>
                                <input name="transition" id="editTransition" type="text" class="js-range-slider" name="my_range" />
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-sm btn-primary">Save Changes</button>
                                <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="modal fade" id="preview-banner" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel3" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                    <h6 class="modal-title" id="exampleModalLabel3">Preview</h6>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="owl-carousel owl-theme" id="previewCarousel">

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary tx-13" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal effect-scale" id="prompt-delete-many" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('common.delete_mutiple_confirmation_title')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p><?php echo e(__('common.delete_mutiple_confirmation')); ?></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-danger" id="btnDeleteMany">Yes, Delete</button>
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal effect-scale" id="prompt-delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('common.delete_confirmation_title')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p><?php echo e(__('common.delete_confirmation')); ?></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-danger" id="btnDelete">Yes, Delete</button>
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal effect-scale" id="prompt-no-selected" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo e(__('common.no_selected_title')); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p><?php echo e(__('common.no_selected')); ?></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagejs'); ?>
    <script src="<?php echo e(asset('lib/bselect/dist/js/bootstrap-select.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/bselect/dist/js/i18n/defaults-en_US.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/ion-rangeslider/js/ion.rangeSlider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/owl.carousel/owl.carousel.js')); ?>"></script>
    <script>
        let listingUrl = "<?php echo e(route('albums.index')); ?>";
        let advanceListingUrl = "";
        let searchType = "<?php echo e($searchType); ?>";
    </script>
    <script src="<?php echo e(asset('js/listing.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
    <?php if($errors->any()): ?>
        <script>
            $('#toastErrorMessage').toast('show');
        </script>
    <?php endif; ?>
    <script>
        $("#editTransition").ionRangeSlider({
            grid: true,
            min: 2,
            max: 10
        });

        let slider = $("#editTransition").data("ionRangeSlider");

        $('#promptQuickEdit').on('show.bs.modal', function (e) {
            //get data-id attribute of the clicked element
            let album = e.relatedTarget;
            let albumId = $(album).data('id');
            let albumName = $(album).data('name');
            let albumTransitionIn = $(album).data('transition-in');
            let albumTransitionOut = $(album).data('transition-out');
            let albumTransition = $(album).data('transition');
            let formAction = "<?php echo e(route('albums.quick_update', 0)); ?>".split('/');
            formAction.pop();
            let editFormAction = formAction.join('/') + "/" + albumId;
            $('#editForm').attr('action', editFormAction);

            $('#editName').val(albumName);
            $('#editTransitionIn').val(albumTransitionIn).change();
            $('#editTransitionOut').val(albumTransitionOut).change();
            // $('#editTransition').val(albumTransition);
            slider.update({
                from: albumTransition
            });
        });

        let ids;
        $('#deleteAlbums').on('click', function() {
            if($(".cb:checked").length <= 0){
                $('#prompt-no-selected').modal('show');
                return false;
            }
            else {
                ids = [];
                $.each($(".cb:checked"), function() {
                    ids.push($(this).data('id'));
                });

                $('#prompt-delete-many').modal('show');
            }
        });

        $('#btnDeleteMany').on('click', function () {
            $('#albumIds').val(ids);
            $('#albumsForm').submit();
        });

        let albumId;
        $('#prompt-delete').on('show.bs.modal', function (e) {
            //get data-id attribute of the clicked element
            let album = e.relatedTarget;
            albumId = $(album).data('id');
            let albumName = $(album).data('name');

            $('#albumName').html(albumName);
        });

        $('#btnDelete').on('click', function() {
            $('#albumForm'+albumId).submit();
        });

        $('#preview-banner').on('show.bs.modal', function (e) {
            let album = e.relatedTarget;
            let albumId = $(album).data('id');
            $('#previewCarousel').html('');
            $.ajax({
                type: "POST",
                data: { _token: "<?php echo e(csrf_token()); ?>"},
                url: "<?php echo e(route('albums.banners', '')); ?>/" + albumId,
                success: function(returnData) {
                    let pathHTML = '';
                    $.each(returnData['banner_paths'], function(index, path) {
                        pathHTML += `<div class="item">
                            <img src="`+path+`">
                        </div>`;
                    });
                    $('#previewCarousel').trigger('destroy.owl.carousel');

                    $('#previewCarousel').html(pathHTML);

                    $('#previewCarousel').owlCarousel({
                        animateOut: returnData['transition_out'],
                        animateIn: returnData['transition_in'],
                        loop: true,
                        dots: false,
                        margin: 0,
                        autoplay: true,
                        autoplayTimeout: (returnData['transition']*1000),
                        autoplayHoverPause: false,
                        nav: false,
                        responsive: {
                            0: {
                                items: 1
                            },
                            600: {
                                items: 1
                            },
                            1000: {
                                items: 1
                            }
                        }
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/admin/cms4/banners/index.blade.php ENDPATH**/ ?>