<!-- Header
============================================= -->
<header id="header" class="header-size-sm" data-sticky-shrink="false">
	<div class="container">
		<div class="header-row">

			<!-- Logo
			============================================= -->
			<div id="logo">
				<a href="<?php echo e(route('home')); ?>" class="standard-logo" data-dark-logo="<?php echo e(Setting::get_company_logo_storage_path()); ?>"><img src="<?php echo e(Setting::get_company_logo_storage_path()); ?>" alt="<?php echo e(Setting::info()->company_name); ?>"></a>
				<a href="<?php echo e(route('home')); ?>" class="retina-logo" data-dark-logo="<?php echo e(Setting::get_company_logo_storage_path()); ?>"><img src="<?php echo e(Setting::get_company_logo_storage_path()); ?>" alt="<?php echo e(Setting::info()->company_name); ?>"></a>
			</div>
			<!-- #logo end -->

			<div class="header-misc d-none d-lg-flex">

				<ul class="header-extras d-none d-sm-flex mx-auto mx-md-0 mb-4 mb-md-0">
					<li>
						<i class="i-plain icon-call m-0"></i>
						<div class="he-text fw-normal">
							Call Us:
							<span href="<?php echo e(Setting::get_company_tel_no()); ?>" target="_top" class="fw-medium"><?php echo e(Setting::get_company_tel_no()); ?></span>
						</div>
					</li>
					<li>
						<i class="i-plain icon-line2-envelope m-0"></i>
						<div class="he-text fw-normal">
							Email Us:
							<span href="mailto:<?php echo e(Setting::get_company_email()); ?>" target="_top" class="fw-medium"><?php echo e(Setting::get_company_email()); ?></span>
						</div>
					</li>
				</ul>

			</div>

		</div>
	</div>

	<div id="header-wrap">
		<div class="container">
			<div class="header-row justify-content-between flex-row-reverse flex-lg-row">

				<div class="header-misc">

					<!-- Top Search
					============================================= -->
					<div id="top-search" class="header-misc-icon">
						<a href="#" id="top-search-trigger"><i class="icon-line-search"></i><i class="icon-line-cross"></i></a>
					</div><!-- #top-search end -->

					<!-- Header Buttons
					============================================= -->
					<?php if(session('member_login_session') == 'active'): ?>
						<div class="header-buttons d-none d-sm-inline-block">
							<a href="javascript:void(0);" onclick="logout()"><i class="fa fa-bracket"></i></a>
						</div>
						
						
						
					<?php else: ?>
						<div class="header-buttons d-none d-sm-inline-block">
							<a href="#modal-register" data-lightbox="inline" class="button button-rounded button-white button-light button-small m-0">log In</a>
						</div>
					<?php endif; ?>
					
					<!-- Login Modal -->
					<div class="modal1 mfp-hide" id="modal-register">
						<div class="card mx-auto" style="max-width: 540px;">
							<div class="card-header py-3 bg-transparent center">
								<h3 class="mb-0 fw-normal">Hello, Welcome Back</h3>
							</div>
							<div class="card-body mx-auto py-5" style="max-width: 70%;">

								
								<form id="login-form" name="login-form" class="mb-0 row" action="<?php echo e(route('members.login')); ?>" method="post">
									<?php echo csrf_field(); ?>
									<div class="col-12">
										<input type="email" id="login_email" name="login_email" class="form-control not-dark" placeholder="Email" required/>
									</div>

									<div class="col-12 mt-4">
										<input type="password" id="login_password" name="login_password" class="form-control not-dark" placeholder="Password" required/>
									</div>

									<div class="col-12">
										<a href="#" class="float-end text-dark fw-light mt-2" onclick=" $('#login-form').hide(); $('#forgot-password-form').show();">Forgot Password?</a>
									</div>

									<div class="col-12 mt-4">
										<button type="submit" class="button w-100 m-0 center" id="login-form-submit" name="login-form-submit" value="login">Login</button>
									</div>
								</form>

								
								<form id="forgot-password-form" name="forgot-password-form" class="mb-0 row" action="<?php echo e(route('members.send-reset-form')); ?>" method="post" style="display: none;">
									<?php echo csrf_field(); ?>
									<p>Enter email to reset password.</p>
									<div class="col-12">
										<input type="email" id="reset_password_email" name="reset_password_email" class="form-control not-dark" placeholder="Email" required/>
									</div>

									<div class="col-12">
										<a href="#" class="float-end text-dark fw-light mt-2" onclick="$('#forgot-password-form').hide(); $('#login-form').show();">Back to login</a>
									</div>

									<div class="col-12 mt-4">
										<button type="submit" class="button w-100 m-0 center" id="login-form-submit" name="login-form-submit" value="login">Reset</button>
									</div>
								</form>
							</div>
						</div>
					</div>

				</div>

				<div id="primary-menu-trigger">
					<svg class="svg-trigger" viewBox="0 0 100 100"><path d="m 30,33 h 40 c 3.722839,0 7.5,3.126468 7.5,8.578427 0,5.451959 -2.727029,8.421573 -7.5,8.421573 h -20"></path><path d="m 30,50 h 40"></path><path d="m 70,67 h -40 c 0,0 -7.5,-0.802118 -7.5,-8.365747 0,-7.563629 7.5,-8.634253 7.5,-8.634253 h 20"></path></svg>
				</div>

				<!-- Primary Navigation
				============================================= -->
				<nav class="primary-menu with-arrows not-dark">
					<?php echo $__env->make('theme.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				</nav>
				<!-- #primary-menu end -->

				<form method="GET" action="<?php echo e(route('search.result')); ?>" class="top-search-form">
					<input type="text" name="searchtxt" class="form-control" value="" placeholder="Type &amp; Hit Enter.." autocomplete="off" aria-describedby="button-addon2">
					<button class="btn btn-outline-primary btn-primary" type="submit" id="button-addon2" hidden><i class="icon-search text-white"></i></button>
				</form>
				
			</div>
		</div>
	</div>
	<div class="header-wrap-clone"></div>
</header>
<!-- #header end --><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/theme/layouts/header.blade.php ENDPATH**/ ?>