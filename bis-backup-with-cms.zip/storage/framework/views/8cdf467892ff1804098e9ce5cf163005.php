<?php
    $menu = Menu::where('is_active', 1)->first();
?>


<ul class="menu-container">
    <?php $__currentLoopData = $menu->parent_navigation(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('theme.layouts.menu-item', ['item' => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php if(session('member_login_session') == 'active'): ?>
        <li class="menu-item <?php echo e(request()->is('portal*') ? 'current' : ''); ?>">
            <a href="<?php echo e(env('APP_URL') . '/portal'); ?>" class="menu-link">
                <div>
                    Portal
                </div>
            </a>
        </li>
    <?php endif; ?>


</ul>

<?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/theme/layouts/menu.blade.php ENDPATH**/ ?>