<?php $__env->startSection('pagecss'); ?>
    <style>
        .dashboard-summary {
            height: 31rem;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container pd-x-0">
        <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
            <div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb breadcrumb-style1 mg-b-10">
                        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                    </ol>
                </nav>
                <h4 class="mg-b-0 tx-spacing--1">Welcome, <?php echo e(Auth::user()->firstname); ?>!</h4>
            </div>
            <div class="d-none d-md-block">
                <a href="<?php echo e(env('APP_URL')); ?>" target="_blank" class="btn btn-sm pd-x-15 btn-white btn-uppercase">
                    <i data-feather="arrow-up-right" class="wd-10 mg-r-5"></i> View Website
                </a>
            </div>
        </div>

        <div class="row row-sm">
            <div class="col-lg-12">
                <div class="row row-sm">
                    <?php if(auth()->user()->has_access_to_pages_module()): ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="card dashboard-widget">
                                <a href="<?php echo e(route('pages.index')); ?>">
                                    <div class="card-body">
                                        <h4 class="tx-bold mg-b-5 lh-1"><i data-feather="layers" class="mg-r-6"></i> <?php echo e(App\Models\Page::totalPages()); ?></h4>
                                        <span class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold">Total Pages</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(auth()->user()->has_access_to_albums_module()): ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="card dashboard-widget">
                                <a href="<?php echo e(route('albums.index')); ?>">
                                    <div class="card-body">
                                        <h4 class="tx-bold mg-b-5 lh-1"><i data-feather="image" class="mg-r-6"></i> <?php echo e(App\Models\Album::totalAlbums()); ?></h4>
                                        <span class="tx-uppercase tx-11 tx-spacing-1 tx-color-02 tx-semibold">Total Banner
                                    Albums</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="row row-sm">
                    <?php if(auth()->user()->has_access_to_pages_module() || auth()->user()->has_access_to_albums_module() || auth()->user()->has_access_to_user_module() || auth()->user()->has_access_to_news_module()): ?>
                        <div class="col-lg-3 col-md-4">
                            <?php if(auth()->user()->has_access_to_pages_module() || auth()->user()->has_access_to_albums_module() || auth()->user()->has_access_to_user_module() || auth()->user()->has_access_to_news_module()): ?>
                                <div class="card dashboard-summary mg-t-20">
                                    <div class="card-header">
                                        Website Summary
                                    </div>
                                    <div class="card-body" style="height:800px !important;">
                                        <?php if(auth()->user()->has_access_to_pages_module()): ?>
                                            <h6><strong>Pages</strong></h6>
                                            <p><a href="<?php echo e(route('pages.index.advance-search')); ?>?status=published"><span class="badge badge-dark"><?php echo e(App\Models\Page::totalPublicPages()); ?></span> Published Pages</a></p>
                                            <p><a href="<?php echo e(route('pages.index.advance-search')); ?>?status=private"><span class="badge badge-dark"><?php echo e(App\Models\Page::totalPrivatePages()); ?></span> Private Pages</a></p>
                                            <p><a href="<?php echo e(route('pages.index.advance-search')); ?>?showDeleted=on"><span class="badge badge-dark"><?php echo e(App\Models\Page::totalDeletePages()); ?></span> Deleted Pages</a></p>
                                            <hr>
                                        <?php endif; ?>
                                        <?php if(auth()->user()->has_access_to_albums_module()): ?>
                                            <h6><strong>Sub Banners</strong></h6>
                                            <p><a href="<?php echo e(route('albums.index')); ?>"><span class="badge badge-dark"><?php echo e(App\Models\Album::totalNotDeletedAlbums()); ?></span> Albums</a></p>
                                            <p><a href="<?php echo e(route('albums.index')); ?>?showDeleted=on"><span class="badge badge-dark"><?php echo e(App\Models\Album::totalDeletePages()); ?></span> Deleted Albums</a></p>
                                            <hr>
                                        <?php endif; ?>
                                        
                                    </div>
                                </div>
                                <?php if(auth()->user()->has_access_to_pages_module() || auth()->user()->has_access_to_news_module() || auth()->user()->has_access_to_albums_module()): ?>
                                    <div class="dashboard-quick mg-t-20">
                                        <?php if(auth()->user()->has_access_to_pages_module()): ?>
                                            <a href="<?php echo e(route('pages.create')); ?>" class="btn btn-sm pd-x-15 btn-primary btn-uppercase btn-block tx-left text-white">
                                                <i data-feather="layers" class="wd-10 mg-r-5"></i> Create a Page
                                            </a>
                                        <?php endif; ?>
                                        <?php if(auth()->user()->has_access_to_albums_module()): ?>
                                            <a href="<?php echo e(route('albums.create')); ?>" class="btn btn-sm pd-x-15 btn-primary btn-uppercase btn-block tx-left text-white">
                                                <i data-feather="image" class="wd-10 mg-r-5"></i> Create an Album
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class=" <?php if(auth()->user()->has_access_to_pages_module() || auth()->user()->has_access_to_albums_module() || auth()->user()->has_access_to_user_module() || auth()->user()->has_access_to_news_module()): ?> col-lg-9 col-md-8 <?php else: ?> col-lg-12 <?php endif; ?>">
                        <div class="card position-relative dashboard-recent mg-t-20 h-xs-100 overflow-y-auto">
                            <div class="card-header position-sticky z-index-10 bg-white" style="top:0">
                                My Recent Activities
                            </div>
                            <div class="card-body">
                                <div class="list-group">
                                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <p class="list-group-item list-group-item-action d-flex flex-column flex-lg-row flex-lg-start mb-2 mb-lg-0">
                                            
                                            <span class="badge badge-dark lh-7 align-self-start mr-2"><?php echo e(ucwords($log->admin->firstname)); ?> <?php echo e(ucwords($log->admin->lastname)); ?></span>
                                            
                                            <span?><?php echo e($log->dashboard_activity); ?> at <span class="text-nowrap"><?php echo e(App\Helpers\Setting::date_for_listing($log->activity_date)); ?></span></span>
                                        </p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        No activities found!
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="card-footer position-sticky z-index-10 bg-white" style="bottom:0">
                                <div class="d-flex justify-content-end">
                                    <span class="tx-12"><a href="<?php echo e(route('users.show', Auth::user()->id)); ?>">Show all activities <i class="fa fa-arrow-right"></i></a></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagejs'); ?>
    <script src="<?php echo e(asset('lib/nestable2/jquery.nestable.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
    <script></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>