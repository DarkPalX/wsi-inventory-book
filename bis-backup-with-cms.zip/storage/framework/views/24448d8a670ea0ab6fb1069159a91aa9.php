<aside class="aside aside-fixed">
    <div class="aside-header">
        <a href="<?php echo e(route('dashboard')); ?>" class="aside-logo">Admin <span>Portal</span></a>
        <a href="" class="aside-menu-link">
            <i data-feather="menu"></i>
            <i data-feather="x"></i>
        </a>
    </div>
    <div class="aside-body">
        <div class="aside-loggedin">
            <?php if(Auth::user()->avatar == ''): ?>
                <div class="d-flex justify-content-center">
                    <a href="<?php echo e(route('account.edit')); ?>" class="avatar wd-100"><img src="<?php echo e(asset('images/user.png')); ?>" class="rounded-circle" alt=""></a>
                </div>
                <div class="aside-loggedin-user tx-center">
                    <h6 class="tx-semibold mg-b-0"><?php echo e(Auth::user()->fullname); ?></h6>
                    <p class="tx-color-03 tx-11 mg-b-0 tx-uppercase"><?php echo e(App\Models\User::userRole(Auth::user()->role_id)); ?></p>
                </div>
            <?php else: ?>
                <div class="d-flex justify-content-center">
                    <a href="<?php echo e(route('account.edit')); ?>" class="avatar wd-100"><img src="<?php echo e(Auth::user()->avatar); ?>" class="rounded-circle" alt=""></a>
                </div>
                <div class="aside-loggedin-user tx-center">
                    <h6 class="tx-semibold mg-b-0"><?php echo e(Auth::user()->fullname); ?></h6>
                    <p class="tx-color-03 tx-11 mg-b-0 tx-uppercase"><?php echo e(App\Models\User::userRole(Auth::user()->role_id)); ?></p>
                </div>
            <?php endif; ?>
        </div>
        <!-- aside-loggedin -->
        <?php echo $__env->make('admin.layouts.sidebar-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</aside><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>