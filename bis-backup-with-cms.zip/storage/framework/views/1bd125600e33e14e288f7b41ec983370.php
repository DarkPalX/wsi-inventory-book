

<?php $__env->startSection('pagecss'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    
    <div class="container topmargin-lg">
        <div class="row">
            WELCOME
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagejs'); ?>
    <script src="<?php echo e(asset('theme/js/scripts/home.js')); ?>"></script>
    
    <script>
        function logout() {
            // Perform any additional actions before logging out, if needed

            // Create a dynamic form
            var form = document.createElement("form");
            form.action = "<?php echo e(route('members.logout')); ?>";
            form.method = "post";

            // Add CSRF token input
            var csrfInput = document.createElement("input");
            csrfInput.type = "hidden";
            csrfInput.name = "_token";
            csrfInput.value = "<?php echo e(csrf_token()); ?>";
            form.appendChild(csrfInput);

            // Append the form to the body and submit
            document.body.appendChild(form);
            form.submit();
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/theme/pages/home.blade.php ENDPATH**/ ?>