<?php $__env->startSection('pagetitle'); ?>
    Account Settings
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagecss'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/dashforge.profile.css')); ?>">

    <style>
        .pass_show{ position: relative }
        .pass_show .ptxt:hover{ color: #333333; }
        .pass_show .ptxt {  position: absolute; top: 50%; right: 10px; z-index: 1; color: #f36c01; margin-top: -10px; cursor: pointer; transition: .3s ease all;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php
    $showTab2 = ($errors->has('email') || $errors->has('current_password') ||$errors->has('new_password') ||$errors->has('confirm_password')) ? true : false;
    $showPassword = ($errors->has('current_password') ||$errors->has('new_password') ||$errors->has('confirm_password')) ? true : false;
?>
<?php $__env->startSection('content'); ?>
    <div class="container pd-x-0">
        <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
            <div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb breadcrumb-style1 mg-b-10">
                        <li class="breadcrumb-item" aria-current="page"><a href="<?php echo e(route('dashboard')); ?>">CMS</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Account Settings</li>
                    </ol>
                </nav>
                <h4 class="mg-b-0 tx-spacing--1">Account Settings</h4>
            </div>
        </div>

        <div class="alert alert-danger print-error-msg" style="display:none" role="alert">
            <ul></ul>
        </div>

        <div class="row row-sm">
            <div class="col-lg-12">
                <ul class="nav nav-tabs" id="myTab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link <?php if(!$showTab2): ?> active <?php endif; ?>" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Personal</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php if($showTab2): ?> active <?php endif; ?> " id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Account</a>
                    </li>
                </ul>
                <div class="tab-content rounded bd bd-gray-300 bd-t-0 pd-20" id="myTabContent">
                    <div class="tab-pane fade <?php if(!$showTab2): ?> show active <?php endif; ?>" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <form class="col-md-6" method="POST" action="<?php echo e(route('account.update', $user->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="media mg-b-30 mg-t-20">
                                <?php if(Auth::user()->avatar == ''): ?>
                                    <img src="<?php echo e(asset('images/user.png')); ?>" id="userLogo" class="wd-100 rounded-circle mg-r-20" alt="">
                                <?php else: ?>
                                    <img src="<?php echo e($user->avatar); ?>" id="userLogo" class="wd-100 rounded-circle mg-r-20" alt="">
                                <?php endif; ?>
                                <div class="media-body pd-t-30">
                                    <h5 class="mg-b-0 tx-inverse tx-bold"><?php echo e($user->fullname); ?></h5>
                                    <p><?php echo e(User::userRole($user->role_id)); ?></p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="d-block">Avatar</label>
                                <div class="custom-file">
                                    <input name="avatar" type="file" class="custom-file-input" id="user_image">
                                    <label class="custom-file-label" for="customFile" id="img_name"><?php if(Auth::user()->avatar == ''): ?> Choose file <?php else: ?> <?php echo e($user->get_image_file_name()); ?> <?php endif; ?></label>
                                </div>
                                <p class="tx-10">
                                    Required image dimension: <?php echo e(env('USER_LOGO_WIDTH')); ?>px by <?php echo e(env('USER_LOGO_HEIGHT')); ?>px <br /> Maximum file size: 1MB <br /> Required file type: .jpeg .png
                                </p>
                            </div>
                            <div class="form-group">
                                <label class="d-block">First Name <span class="tx-danger">*</span></label>
                                <input type="text" name="firstname" class="form-control" required value="<?php echo e(old('firstname', $user->firstname)); ?>">
                                <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label class="d-block">Last Name <span class="tx-danger">*</span></label>
                                <input type="text" name="lastname" class="form-control" required value="<?php echo e(old('lastname', $user->lastname)); ?>">
                                <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-row">
                                <div class="col-lg-12 mg-t-10">
                                    <button class="btn btn-primary btn-sm btn-uppercase" type="submit">Save Changes</button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="tab-pane fade <?php if($showTab2): ?> show active <?php endif; ?>" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        <form class="col-md-6" method="post" action="<?php echo e(route('account.update-email')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="d-block">Email <i class="tx-danger">*</i></label>
                                        <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                        <input type="email" name="email" class="form-control" required value="<?php echo e($user->email); ?>" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <button class="btn btn-primary btn-sm btn-uppercase" type="submit">Change Email</button>
                                    </div>
                                </div>
                            </div>
                        </form>

                        <div class="col-md-6">
                            <div class="form-group">
                                <a class="btn btn-white tx-primary mg-t-20" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                                    <i data-feather="alert-circle"></i> Change Password
                                </a>

                                <div class="collapse mg-t-15 <?php if($showPassword): ?> show <?php endif; ?>" id="collapseExample">
                                    <form method="post" action="<?php echo e(route('account.update-password')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div class="form-group">
                                            <label class="d-block">Old Password *</label>
                                            <input type="password" name="current_password" class="form-control" required>
                                            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label class="d-block">New Password * <span class="tx-color-03">(Min. 8, alphanumeric, at least 1 upper case, 1 number and 1 special character)</span></label>
                                            <input type="password" name="new_password" class="form-control" required>
                                            <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <label class="d-block">Confirm Password *</label>
                                            <input type="password" class="form-control" name="confirm_password" required>
                                            <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-row">
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <button class="btn btn-primary btn-sm btn-uppercase">Save Password</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="pos-fixed b-10 r-10">
        <div id="toast_successs" class="toast bg-success bd-0 wd-350" data-delay="3000" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-body pd-6 tx-white">
                <button type="button" class="ml-2 mb-1 close tx-normal tx-shadow-none" data-dismiss="toast" aria-label="Close">
                    <span class="tx-white" aria-hidden="true">&times;</span>
                </button>
                <h6 class="mg-b-15 mg-t-15 tx-white"><i data-feather="alert-circle"></i> SUCCESS!</h6>
                <p id="a_msg"></p>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagejs'); ?>
    <script src="<?php echo e(asset('scripts/account/update.js')); ?>"></script>

    
    <script>
        let BANNER_WIDTH = "<?php echo e(env('USER_LOGO_WIDTH')); ?>";
        let BANNER_HEIGHT =  "<?php echo e(env('USER_LOGO_HEIGHT')); ?>";
    </script>
    <script src="<?php echo e(asset('js/image-upload-validation.js')); ?>"></script>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
    <script>
        function readURL(file) {
            let reader = new FileReader();

            reader.onload = function(e) {
                $('#userLogo').attr('src', e.target.result);
                $('#img_name').html(file.name);
            }

            reader.readAsDataURL(file);
        }

        $("#user_image").change(function(evt) {
            validate_images(evt, readURL);
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/admin/settings/account/edit.blade.php ENDPATH**/ ?>