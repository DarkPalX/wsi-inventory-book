<?php

namespace App\Models\Custom;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class BookCategory extends Model
{
    use HasFactory, SoftDeletes;
    
    protected $table = 'book_categories';
    protected $fillable = ['name', 'slug', 'description', 'order'];

    
    public function book()
    {
        return $this->belongsTo(Book::class);
    }
}