<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('books', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable(false);
            $table->string('subtitle')->nullable();
            $table->string('edition')->default('1st Edition');
            $table->string('isbn')->nullable();
            $table->date('publication_date');
            $table->string('copyright')->nullable();
            $table->unsignedBigInteger('publisher_id');
            $table->string('format')->nullable();
            $table->string('paper_height')->nullable();
            $table->string('paper_width')->nullable();
            $table->string('cover_height')->nullable();
            $table->string('cover_width')->nullable();
            $table->integer('pages')->nullable();
            $table->string('color')->nullable();
            $table->unsignedBigInteger('category_id');
            $table->unsignedBigInteger('author_id');
            $table->string('sku')->nullable();
            $table->string('file_url')->nullable();
            $table->decimal('total_cost', 16, 2);
            $table->string('editor')->nullable();
            $table->string('researcher')->nullable();
            $table->string('writer')->nullable();
            $table->string('graphic_designer')->nullable();
            $table->string('layout_designer')->nullable();
            $table->string('photographer')->nullable();
            $table->string('markup_fee')->nullable();
            $table->unsignedBigInteger('agency_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('books');
    }
};
