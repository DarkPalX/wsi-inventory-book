<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<meta http-equiv="x-ua-compatible" content="IE=edge">
	<meta name="author" content="SemiColonWeb">
	<meta name="description" content="Get Canvas to build powerful websites easily with the Highly Customizable &amp; Best Selling Bootstrap Template, today.">

	<!-- Font Imports -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:ital@0;1&display=swap" rel="stylesheet">

	<!-- Core Style -->
	<link rel="stylesheet" href="{{ asset('theme/style.css') }}">

	<!-- Font Icons -->
	<link rel="stylesheet" href="{{ asset('theme/css/font-icons.css') }}">

	<!-- Custom CSS -->
	<link rel="stylesheet" href="{{ asset('theme/css/custom.css') }}">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	@yield('pagecss')
	
	<!-- Document Title
	============================================= -->

	@if (isset($page->name) && $page->name == 'Home')
		<title>{{ Setting::info()->company_name }}</title>
	@else
		<title>{{ (empty($page->meta_title) ? $page->name : ($page->meta_title == "title" ? $page->name : $page->meta_title) ) }} | {{ Setting::info()->company_name }}</title>
	@endif

	@if(!empty($page->meta_description))
		<meta name="description" content="{{ $page->meta_description }}">
	@endif

	@if(!empty($page->meta_keyword))
		<meta name="keywords" content="{{ $page->meta_keyword }}">
	@endif
	
	<!-- Favicon
	============================================= -->
	<link rel="icon" href="{{ asset('storage/icons/'.Setting::get_company_favicon_storage_path()); }}" type="image/x-icon">

</head>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">
		
		<!-- Header
		============================================= -->
		{{-- @include('theme.layouts.header') --}}
		<!-- #header end -->

		<!-- Slider
		============================================= -->
		{{-- @include('theme.layouts.banner') --}}
		
		<!-- #slider end -->

		<!-- Content
		============================================= -->
		<section id="website-content">
			@yield('content')
		</section><!-- #content end -->

		<!-- Alert
		============================================= -->
		@include('theme.layouts.alert')<!-- #alert end -->

		<!-- Footer
		============================================= -->
		{{-- @include('theme.layouts.footer')<!-- #footer end --> --}}

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="uil uil-angle-up"></div>

	<!-- Cookie
	============================================= -->
	{{-- <div class="alert text-center cookiealert" role="alert" id="popupPrivacy" style="display: none;">
		{!! \Setting::info()->data_privacy_popup_content !!} <a href="{{ route('privacy-policy') }}" target="_blank">Learn more</a>
		<button type="button" id="cookieAcceptBarConfirm" class="btn btn-primary btn-sm acceptcookies px-3" aria-label="Close">
			I agree
		</button>
	</div><!-- #cookie end --> --}}
	
	<!-- JavaScripts
	============================================= -->
	<script src="{{ asset('theme/js/plugins.min.js') }}"></script>
	<script src="{{ asset('theme/js/functions.bundle.js') }}"></script>
	
	<script>
		function showLoginForm() {
			document.getElementById('cover-banner').classList.add('slide-up');
			document.getElementById('login-section').classList.add('show');
		}
	</script>




	{{-- old scripts --}}

	@php
		$animationIn = Setting::bannerTransition($page->album->transition_in ?? 1);
		$animationOut = Setting::bannerTransition($page->album->transition_out ?? 1);
		$animationTimeOut = 4000;
	@endphp

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript">
        var bannerFxIn = "{{ $animationIn }}";
        var bannerFxOut = "{{ $animationOut }}";
        var bannerCaptionFxIn = "fadeInUp";
        var autoPlayTimeout = "{{ $animationTimeOut }}";
        var bannerID = "banner";
    </script>

	<script src="{{ asset('theme/js/slick.js') }}"></script>
	<script src="{{ asset('theme/js/slick.extension.js') }}"></script>
	<script src="{{ asset('theme/js/cookiealert.js') }}"></script>
	<script src="{{ asset('theme/js/functions.js') }}"></script>
	
	@yield('pagejs')
	
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id={{ Setting::info()->google_analytics }}"></script>

	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', '{{ Setting::info()->google_analytics }}');
	</script>

	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-D9LMZPFTGV"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', 'G-D9LMZPFTGV');
	</script>

</body>
</html>