<!-- #alert start -->
<div class="container">
    <div class="row justify-content-end">
        <div class="col-md-6">
            <?php if($message = Session::get('login_error')): ?>
                <div id="errorAlert" class="alert alert-danger alert-dismissible fade show" role="alert" style="position: fixed; top: 15px; right: 15px; z-index: 1000;">
                    <i data-feather="alert-circle" class="mg-r-10"></i> <?php echo e($message); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <script>
                    setTimeout(function(){
                        $('#errorAlert').fadeOut('slow');
                    }, 3500);
                </script>
            <?php endif; ?>

            <?php if($message = Session::get('login_msg')): ?>
                <div id="successAlert" class="alert alert-success alert-dismissible fade show" role="alert" style="position: fixed; top: 15px; right: 15px; z-index: 1000;">
                    <i data-feather="alert-circle" class="mg-r-10"></i> <?php echo e($message); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <script>
                    setTimeout(function(){
                        $('#successAlert').fadeOut('slow');
                    }, 3500);
                </script>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="container">
    <div class="row justify-content-end">
        <div class="col-md-6">
            <?php if($message = Session::get('inquiry_error')): ?>
                <div id="errorAlert" class="alert alert-danger alert-dismissible fade show" role="alert" style="position: fixed; top: 15px; right: 15px; z-index: 1000;">
                    <i data-feather="alert-circle" class="mg-r-10"></i> <?php echo e($message); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <script>
                    setTimeout(function(){
                        $('#errorAlert').fadeOut('slow');
                    }, 3500);
                </script>
            <?php endif; ?>

            <?php if($message = Session::get('inquiry_msg')): ?>
                <div id="successAlert" class="alert alert-success alert-dismissible fade show" role="alert" style="position: fixed; top: 15px; right: 15px; z-index: 1000;">
                    <i data-feather="alert-circle" class="mg-r-10"></i> <?php echo e($message); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
                <script>
                    setTimeout(function(){
                        $('#successAlert').fadeOut('slow');
                    }, 3500);
                </script>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- #alert end --><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/theme/layouts/alert.blade.php ENDPATH**/ ?>