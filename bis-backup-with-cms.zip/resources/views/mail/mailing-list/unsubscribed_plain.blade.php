You will be missed!

You have been unsubscribed from {{ $setting->website_name }} mailing list.


{{ $setting->company_name }}
{{ $setting->company_address }}
{{ $setting->tel_no }} | {{ $setting->mobile_no }}

{{ url('/') }}
