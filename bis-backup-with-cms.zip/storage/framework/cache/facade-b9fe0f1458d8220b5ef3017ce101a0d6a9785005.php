<?php

namespace Facades\App\Helpers;

use Illuminate\Support\Facades\Facade;

/**
 * @see \App\Helpers\ListingHelper
 */
class ListingHelper extends Facade
{
    /**
     * Get the registered name of the component.
     */
    protected static function getFacadeAccessor(): string
    {
        return 'App\Helpers\ListingHelper';
    }
}
