@extends('theme.main')

@section('pagecss')
    <style>
        #cover-banner {
            position: absolute;
            width: 100%;
            height: 100%;
            background: url('{{ asset('theme/images/dfa-bg-2.jpg') }}') center center no-repeat;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            text-align: center;
            color: #fff;
            transition: transform 0.5s ease-in-out;
            z-index: 10;
        }

        #cover-banner::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 255, 0.7); /* Blue color with 50% opacity */
            z-index: -1; /* Ensure the overlay is behind the content */
        }

        #cover-banner h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            color: #fff; /* Ensure the text color is white or another color */
            text-shadow: 
                2px 2px 5px #000,  
                -2px -2px 5px #000,  
                2px -2px 5px #000,  
                -2px  2px 5px #000;
        }


        #cover-banner img {
            max-width: 150px;
            margin: 20px 0;
        }

        #cover-banner p {
            font-size: 1.5em;
            margin-bottom: 20px;
        }

        #cover-banner .button-container {
            display: flex;
            justify-content: center;
        }

        #cover-banner button {
            margin: 10px;
            padding: 15px 30px;
            font-size: 18px;
            border: none;
            background-color: #333;
            color: #fff;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        #cover-banner button:hover {
            background-color: #555;
        }

        #cover-banner.slide-up {
            transform: translateY(-100%);
        }

        #login-section {
            opacity: 0;
            transition: opacity 0.5s ease-in-out;
            z-index: 1;
        }

        #login-section.show {
            opacity: 1;
        }

        #blurred-bg {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('{{ asset('theme/images/dfa-bg-2.jpg') }}') center center no-repeat;
            background-size: cover;
            /* filter: blur(10px); Adjust the blur radius as needed */
            z-index: -1; /* Ensure the blurred background is behind the content */
        }

        /* Additional styles to ensure content is above the blurred background */
        .content-wrap {
            position: relative;
            z-index: 1;
        }

    </style>
@endsection

@section('content')

    <!-- Cover Banner -->
    <div id="cover-banner">

        <img src="{{ Setting::get_company_logo_storage_path() }}" alt="DFA Logo" style="max-width: 170px; margin: 20px 0;">
        
        <h1 class="text-uppercase text-light" style="font-size: 70px;">Department of Foreign Affairs</h1>

        <h2 class="text-white">BOOK INVENTORY SYSTEM</h2>
        <div class="button-container">
            <button class="bg-youtube border border-youtube" onclick="showLoginForm()">Login</button>
            <button class="bg-transparent border border-light" onclick="window.location.href='signup.html'">Sign Up</button>
        </div>
    </div>

    <div class="content-wrap py-0">
        <div class="section p-0 m-0 h-100 position-absolute" id="blurred-bg"></div>
        <div class="section bg-transparent min-vh-100 p-0 m-0">
            <div class="vertical-middle">
                <div class="container-fluid py-5 mx-auto">
                    <div class="text-center">
                        <a href="index.html"><img src="{{ Setting::get_company_logo_storage_path() }}" alt="DFA Logo" style="max-width: 170px; margin: 20px 0;"></a>
                    </div>
    
                    <div id="login-section" class="card mx-auto rounded-0 border-0" style="max-width: 400px; background-color: rgba(255,255,255,0.93);">
                        <div class="card-body" style="padding: 40px;">
                            <form id="login-form" name="login-form" class="mb-0" action="#" method="post">
                                <h3>Login to your Account</h3>
    
                                <div class="row">
                                    <div class="col-12 form-group">
                                        <label for="login-form-username">Username:</label>
                                        <input type="text" id="login-form-username" name="login-form-username" value="" class="form-control not-dark">
                                    </div>
    
                                    <div class="col-12 form-group">
                                        <label for="login-form-password">Password:</label>
                                        <input type="password" id="login-form-password" name="login-form-password" value="" class="form-control not-dark">
                                    </div>
    
                                    <div class="col-12 form-group">
                                        <div class="d-flex justify-content-between">
                                            <button class="button button-3d button-black m-0" id="login-form-submit" name="login-form-submit" value="login">Login</button>
                                            <a href="#">Forgot Password?</a>
                                        </div>
                                    </div>
                                </div>
                            </form>
    
                            <div class="line line-sm"></div>
    
                            <div class="w-100 text-center">
                                <h4 class="mb-3">or Login with:</h4>
                                <a href="#" class="button button-rounded bg-facebook">Facebook</a>
                                <span class="d-none d-md-inline-block">or</span>
                                <a href="#" class="button button-rounded bg-google">Google</a>
                            </div>
                        </div>
                    </div>
    
                    <div class="text-center dark mt-3"><small>Copyrights &copy; All Rights Reserved by Canvas Inc.</small></div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('pagejs')
    <script src="{{ asset('theme/js/scripts/home.js') }}"></script>
    
    <script>
        function logout() {
            // Perform any additional actions before logging out, if needed

            // Create a dynamic form
            var form = document.createElement("form");
            form.action = "{{ route('members.logout') }}";
            form.method = "post";

            // Add CSRF token input
            var csrfInput = document.createElement("input");
            csrfInput.type = "hidden";
            csrfInput.name = "_token";
            csrfInput.value = "{{ csrf_token() }}";
            form.appendChild(csrfInput);

            // Append the form to the body and submit
            document.body.appendChild(form);
            form.submit();
        }
    </script>
@endsection