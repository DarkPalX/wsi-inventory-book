
<div class="content-search content-company">
    <h3 class="tx-15 mg-b-0"><?php echo e(App\Helpers\Setting::info()->company_name); ?></h3>
</div>

<div class="dropdown dropdown-profile">
    <a href="" class="dropdown-link" data-toggle="dropdown" data-display="static">
        <?php if(Auth::user()->avatar == ''): ?>
            <div class="avatar avatar-sm"><img src="<?php echo e(asset('images/user.png')); ?>" class="rounded-circle" alt=""></div>
        <?php else: ?>
            <div class="avatar avatar-sm"><img src="<?php echo e(Auth::user()->avatar); ?>" class="rounded-circle" alt=""></div>
        <?php endif; ?>
    </a>
    <!-- dropdown-link -->
    <div class="dropdown-menu dropdown-menu-right tx-13">
        <h6 class="tx-semibold mg-b-5"><?php echo e(Auth::user()->fullname); ?></h6>
        <p class="tx-12 tx-color-03"><?php echo e(Auth::user()->role); ?></p>
        <div class="dropdown-divider"></div>

        <a href="<?php echo e(route('account.edit', Auth::user()->id )); ?>" class="dropdown-item"><i data-feather="edit-3"></i> Account Settings</a>
        <a href="" target="_blank" class="dropdown-item"><i data-feather="help-circle"></i> Help</a>
        <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i data-feather="log-out"></i>Log Out</a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="roleid" value="<?php echo e(Auth::user()->role_id); ?>">
        </form>
    </div>
    <!-- dropdown-menu -->
</div>
<!-- dropdown -->

<?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>