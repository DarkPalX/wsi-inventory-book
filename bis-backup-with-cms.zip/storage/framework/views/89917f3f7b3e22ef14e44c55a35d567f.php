<?php $__env->startSection('pagetitle'); ?>
    User Management
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagecss'); ?>
    <link href="<?php echo e(asset('lib/ion-rangeslider/css/ion.rangeSlider.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container pd-x-0">
        <div class="d-sm-flex align-items-center justify-content-between mg-b-20 mg-lg-b-25 mg-xl-b-30">
            <div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb breadcrumb-style1 mg-b-5">
                        <li class="breadcrumb-item" aria-current="page">CMS</li>
                        <li class="breadcrumb-item active" aria-current="page">Users</li>
                    </ol>
                </nav>
                <h4 class="mg-b-0 tx-spacing--1">Manage Users</h4>
            </div>
        </div>

        <div class="row row-sm">

            <!-- Start Filters -->
            <div class="col-md-12">

                <div class="filter-buttons mg-b-10">
                    <div class="d-md-flex bd-highlight">
                        <div class="bd-highlight mg-r-10 mg-t-10">
                            <div class="dropdown d-inline mg-r-5">
                                <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Filters
                                </button>
                                <div class="dropdown-menu">
                                    <form id="filterForm" class="pd-20">
                                        <div class="form-group">
                                            <label for="exampleDropdownFormEmail1"><?php echo e(__('common.sort_by')); ?></label>
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="orderBy1" name="orderBy" class="custom-control-input" value="updated_at" <?php if($filter->orderBy == 'updated_at'): ?> checked <?php endif; ?>>
                                                <label class="custom-control-label" for="orderBy1"><?php echo e(__('common.date_modified')); ?></label>
                                            </div>
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="orderBy2" name="orderBy" class="custom-control-input" value="name" <?php if($filter->orderBy == 'name'): ?> checked <?php endif; ?>>
                                                <label class="custom-control-label" for="orderBy2"><?php echo e(__('common.name')); ?></label>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleDropdownFormEmail1"><?php echo e(__('common.sort_order')); ?></label>
                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="sortByAsc" name="sortBy" class="custom-control-input" value="asc" <?php if($filter->sortBy == 'asc'): ?> checked <?php endif; ?>>
                                                <label class="custom-control-label" for="sortByAsc"><?php echo e(__('common.ascending')); ?></label>
                                            </div>

                                            <div class="custom-control custom-radio">
                                                <input type="radio" id="sortByDesc" name="sortBy" class="custom-control-input" value="desc"  <?php if($filter->sortBy == 'desc'): ?> checked <?php endif; ?>>
                                                <label class="custom-control-label" for="sortByDesc"><?php echo e(__('common.descending')); ?></label>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" id="showDeleted" name="showDeleted" class="custom-control-input" <?php if($filter->showDeleted): ?> checked <?php endif; ?>>
                                                <label class="custom-control-label" for="showDeleted">Show Inactive User</label>
                                            </div>
                                        </div>
                                        <div class="form-group mg-b-40">
                                            <label class="d-block"><?php echo e(__('common.item_displayed')); ?></label>
                                            <input id="displaySize" type="text" class="js-range-slider" name="perPage" value="<?php echo e($filter->perPage); ?>"/>
                                        </div>
                                        <button id="filter" type="button" class="btn btn-sm btn-primary"><?php echo e(__('common.apply_filters')); ?></button>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="ml-auto bd-highlight mg-t-10 mg-r-10">
                            <form class="form-inline" id="searchForm">
                                <div class="search-form mg-r-10">
                                    <input name="search" type="search" id="search" class="form-control"  placeholder="Search by Name" value="<?php echo e($filter->search); ?>">
                                    <button class="btn filter" type="button" id="btnSearch"><i data-feather="search"></i></button>
                                </div>
                            </form>
                        </div>
                        <div class="mg-t-10">
                            <?php if(auth()->user()->has_access_to_route('users.create')): ?>
                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('users.create')); ?>">Create a User</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            </div>
            <!-- End Filters -->


            <!-- Start Pages -->
            <div class="col-md-12">
                <div class="table-list mg-b-10">
                    <div class="table-responsive-lg">
                        <table class="table mg-b-0 table-light table-hover" style="width:100%;">
                            <thead>
                            <tr>
                                <th scope="col" width="30%">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Role</th>
                                <th scope="col">Status</th>
                                <th scope="col">Options</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th>
                                        <strong <?php if($user->is_active == 0): ?> style="text-decoration:line-through;" <?php endif; ?>> <?php echo e($user->fullname); ?></strong>
                                    </th>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><span class="badge badge-primary"><?php echo e(User::userRole($user->role_id)); ?></span></td>
                                    <td>
                                        <?php if($user->is_active == 1): ?>
                                            <span class="badge badge-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <nav class="nav table-options justify-content-end flex-nowrap">
                                            <?php if($user->is_active == 1): ?>
                                                <a class="nav-link" href="<?php echo e(route('users.edit', $user->id)); ?>" title="Edit User"><i data-feather="edit"></i></a>
                                            <?php endif; ?>
                                                <a class="nav-link" target="_blank" href="<?php echo e(route('users.show', $user->id)); ?>" title="View User"><i data-feather="eye"></i></a>

                                            <?php if($user->is_active == 1): ?>
                                                <a class="nav-link deactivate_user" data-user_id="<?php echo e($user->id); ?>" href="#" title="Deactivate User" data-toggle="modal" data-target="#modalUserDeactivate"><i data-feather="user-x"></i></a>
                                            <?php else: ?>
                                                <a class="nav-link activate_user" data-user_id="<?php echo e($user->id); ?>" href="#" title="Activate User" data-toggle="modal" data-target="#modalUserActivate"><i data-feather="user-check"></i></a>
                                            <?php endif; ?>
                                        </nav>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" style="text-align: center;"> <p class="text-danger">No users found.</p></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Pages -->

            <!-- Start Navigation -->
            <div class="col-md-6">
                <div class="mg-t-5">
                    <?php if($users->firstItem() == null): ?>
                        <p class="tx-gray-400 tx-12 d-inline"><?php echo e(__('common.showing_zero_items')); ?></p>
                    <?php else: ?>
                        <p class="tx-gray-400 tx-12 d-inline">Showing <?php echo e($users->firstItem()); ?> to <?php echo e($users->lastItem()); ?> of <?php echo e($users->total()); ?> users</p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="text-md-right float-md-right mg-t-5">
                    <div>
                        <?php echo e($users->appends((array) $filter)->links()); ?>

                    </div>
                </div>
            </div>
            <!-- End Navigation -->

        </div>
    </div>
    <?php echo $__env->make('admin.users.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pagejs'); ?>
    <script src="<?php echo e(asset('lib/bselect/dist/js/bootstrap-select.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/bselect/dist/js/i18n/defaults-en_US.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/ion-rangeslider/js/ion.rangeSlider.min.js')); ?>"></script>
    
    <script>
        $(document).on('click','.deactivate_user', function(){
            $('#modalUserDeactivate').show();

            $('#deactivate_user_id').val($(this).data('user_id'));
        });

        $(document).on('click','.activate_user', function(){
            $('#modalUserAactivate').show();

            $('#activate_user_id').val($(this).data('user_id'));
        });
    </script>

    <script>
        let listingUrl = "<?php echo e(route('users.index')); ?>";
        let advanceListingUrl = "";
        let searchType = "<?php echo e($searchType); ?>";
    </script>
    <script src="<?php echo e(asset('js/listing.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('customjs'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/admin/users/index.blade.php ENDPATH**/ ?>