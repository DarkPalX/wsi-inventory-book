<?php $page = $item->page; ?>
<?php if(!empty($page) && $item->is_page_type() && $page->is_published()): ?>
    <li class="menu-item <?php if( url()->current() == $page->get_url() || ($page->id == 1 && url()->current() == env('APP_URL')) ): ?> current <?php endif; ?> <?php if($item->has_sub_menus()): ?> sub-menu <?php endif; ?> <?php if(Str::contains(url()->current(), $page->get_url())): ?> current <?php endif; ?>">
        <a href="<?php echo e($page->get_url()); ?>" class="menu-link">
            <div>
                <?php if(!empty($page->label)): ?>
                    <?php echo e($page->label); ?> 
                <?php else: ?>
                    <?php echo e($page->name); ?> 
                <?php endif; ?>
            </div>
        </a>
        <?php if($item->has_sub_menus()): ?>
            <ul class="sub-menu-container">
                <?php $__currentLoopData = $item->sub_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('theme.layouts.menu-item', ['item' => $subItem], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </li>
<?php elseif($item->is_external_type()): ?>
    <li class="menu-item <?php echo e(Str::contains(url()->current(), $item->uri) ? 'current' : ''); ?>">
        <a href="<?php echo e(env('APP_URL')."/".$item->uri); ?>" class="menu-link" target="<?php echo e($item->target); ?>"><div><?php echo e($item->label); ?></div></a>
        <?php if($item->has_sub_menus()): ?>
            <ul class="sub-menu-container">
                <?php $__currentLoopData = $item->sub_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('theme.layouts.menu-item', ['item' => $subItem], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </li>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/theme/layouts/menu-item.blade.php ENDPATH**/ ?>