<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>

	<meta http-equiv="content-type" content="text/html; charset=utf-8">
	<meta http-equiv="x-ua-compatible" content="IE=edge">
	<meta name="author" content="SemiColonWeb">
	<meta name="description" content="Get Canvas to build powerful websites easily with the Highly Customizable &amp; Best Selling Bootstrap Template, today.">

	<!-- Font Imports -->
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:ital@0;1&display=swap" rel="stylesheet">

	<!-- Core Style -->
	<link rel="stylesheet" href="<?php echo e(asset('theme/style.css')); ?>">

	<!-- Font Icons -->
	<link rel="stylesheet" href="<?php echo e(asset('theme/css/font-icons.css')); ?>">

	<!-- Custom CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('theme/css/custom.css')); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<?php echo $__env->yieldContent('pagecss'); ?>
	
	<!-- Document Title
	============================================= -->

	<?php if(isset($page->name) && $page->name == 'Home'): ?>
		<title><?php echo e(Setting::info()->company_name); ?></title>
	<?php else: ?>
		<title><?php echo e((empty($page->meta_title) ? $page->name : ($page->meta_title == "title" ? $page->name : $page->meta_title) )); ?> | <?php echo e(Setting::info()->company_name); ?></title>
	<?php endif; ?>

	<?php if(!empty($page->meta_description)): ?>
		<meta name="description" content="<?php echo e($page->meta_description); ?>">
	<?php endif; ?>

	<?php if(!empty($page->meta_keyword)): ?>
		<meta name="keywords" content="<?php echo e($page->meta_keyword); ?>">
	<?php endif; ?>
	
	<!-- Favicon
	============================================= -->
	<link rel="icon" href="<?php echo e(asset('storage/icons/'.Setting::get_company_favicon_storage_path())); ?>" type="image/x-icon">

</head>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">
		
		<!-- Header
		============================================= -->
		
		<!-- #header end -->

		<!-- Slider
		============================================= -->
		
		
		<!-- #slider end -->

		<!-- Content
		============================================= -->
		<section id="website-content">
			<?php echo $__env->yieldContent('content'); ?>
		</section><!-- #content end -->

		<!-- Alert
		============================================= -->
		<?php echo $__env->make('theme.layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><!-- #alert end -->

		<!-- Footer
		============================================= -->
		

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="uil uil-angle-up"></div>

	<!-- Cookie
	============================================= -->
	
	
	<!-- JavaScripts
	============================================= -->
	<script src="<?php echo e(asset('theme/js/plugins.min.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/functions.bundle.js')); ?>"></script>
	
	<script>
		function showLoginForm() {
			document.getElementById('cover-banner').classList.add('slide-up');
			document.getElementById('login-section').classList.add('show');
		}
	</script>




	

	<?php
		$animationIn = Setting::bannerTransition($page->album->transition_in ?? 1);
		$animationOut = Setting::bannerTransition($page->album->transition_out ?? 1);
		$animationTimeOut = 4000;
	?>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript">
        var bannerFxIn = "<?php echo e($animationIn); ?>";
        var bannerFxOut = "<?php echo e($animationOut); ?>";
        var bannerCaptionFxIn = "fadeInUp";
        var autoPlayTimeout = "<?php echo e($animationTimeOut); ?>";
        var bannerID = "banner";
    </script>

	<script src="<?php echo e(asset('theme/js/slick.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/slick.extension.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/cookiealert.js')); ?>"></script>
	<script src="<?php echo e(asset('theme/js/functions.js')); ?>"></script>
	
	<?php echo $__env->yieldContent('pagejs'); ?>
	
	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo e(Setting::info()->google_analytics); ?>"></script>

	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', '<?php echo e(Setting::info()->google_analytics); ?>');
	</script>

	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-D9LMZPFTGV"></script>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', 'G-D9LMZPFTGV');
	</script>

</body>
</html><?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/theme/main.blade.php ENDPATH**/ ?>