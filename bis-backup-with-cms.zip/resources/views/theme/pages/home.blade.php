@extends('theme.main')

@section('pagecss')
@endsection

@section('content')

    
    <div class="container topmargin-lg">{{-- bottommargin-lg --}}
        <div class="row">
            WELCOME
        </div>
    </div>
    
@endsection

@section('pagejs')
    <script src="{{ asset('theme/js/scripts/home.js') }}"></script>
    
    <script>
        function logout() {
            // Perform any additional actions before logging out, if needed

            // Create a dynamic form
            var form = document.createElement("form");
            form.action = "{{ route('members.logout') }}";
            form.method = "post";

            // Add CSRF token input
            var csrfInput = document.createElement("input");
            csrfInput.type = "hidden";
            csrfInput.name = "_token";
            csrfInput.value = "{{ csrf_token() }}";
            form.appendChild(csrfInput);

            // Append the form to the body and submit
            document.body.appendChild(form);
            form.submit();
        }
    </script>
@endsection