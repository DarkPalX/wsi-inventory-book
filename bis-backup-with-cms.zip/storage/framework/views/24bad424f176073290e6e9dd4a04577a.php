<ul class="nav nav-aside">
    <li class="nav-item">
        <a href="<?php echo e(route('home')); ?>" target="_blank" class="nav-link">
            <i data-feather="external-link"></i>
            <span>View Website</span>
        </a>
    </li>
    <li class="nav-label mg-t-25">CMS</li>
    <li class="nav-item <?php if(url()->current() == route('dashboard')): ?> active <?php endif; ?>">
        <a href="<?php echo e(route('dashboard')); ?>" class="nav-link"><i data-feather="home"></i><span>Dashboard</span></a>
    </li>

    <li class="nav-item with-sub <?php if(request()->routeIs('account*') || request()->routeIs('website-settings*') || request()->routeIs('audit*')): ?> active show <?php endif; ?>">
        <a href="" class="nav-link"><i data-feather="settings"></i> <span>Settings</span></a>
        <ul>
            <li <?php if(\Route::current()->getName() == 'account.edit'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('account.edit')); ?>">Account Settings</a></li>

            <?php if(auth()->user()->has_access_to_website_settings_module()): ?>
                <li <?php if(\Route::current()->getName() == 'website-settings.edit'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('website-settings.edit')); ?>">Website Settings</a></li>
            <?php endif; ?>

            <?php if(auth()->user()->has_access_to_audit_logs_module()): ?>
                <li <?php if(\Route::current()->getName() == 'audit-logs.index'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('audit-logs.index')); ?>">Audit Trail</a></li>
            <?php endif; ?>
        </ul>
    </li>

    <?php if(auth()->user()->is_an_admin()): ?>
        <li class="nav-item with-sub <?php if(request()->routeIs('users*')): ?> active show <?php endif; ?>">
            <a href="" class="nav-link"><i data-feather="users"></i> <span>Users</span></a>
            <ul>
                <li <?php if(\Route::current()->getName() == 'users.index' || \Route::current()->getName() == 'users.edit'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.index')); ?>">Manage Users</a></li>
                <li <?php if(\Route::current()->getName() == 'users.create'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.create')); ?>">Create a User</a></li>
            </ul>
        </li>
    <?php endif; ?>

    <?php if(auth()->user()->is_an_admin()): ?>
        <li class="nav-item with-sub <?php if(request()->routeIs('role*') || request()->routeIs('access*') || request()->routeIs('permission*')): ?> active show <?php endif; ?>">
            <a href="" class="nav-link"><i data-feather="user"></i> <span>Account Management</span></a>
            <ul>
                <li <?php if(request()->routeIs('role*')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('role.index')); ?>">Roles</a></li>
                <li <?php if(request()->routeIs('access*')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('access.index')); ?>">Access Rights</a></li>
                <li <?php if(request()->routeIs('permission*')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('permission.index')); ?>">Permissions</a></li>
            </ul>
        </li>
    <?php endif; ?>


    <?php if(auth()->user()->has_access_to_module('ecommerce')): ?>
        <li class="nav-label mg-t-25">Maintenance</li>
    <?php endif; ?>

    <?php if(auth()->user()->is_an_admin()): ?>
        <li class="nav-item with-sub <?php if(request()->routeIs('users*')): ?> active show <?php endif; ?>">
            <a href="" class="nav-link"><i data-feather="book"></i> <span>Book Management</span></a>
            <ul>
                <li <?php if(\Route::current()->getName() == 'users.index' || \Route::current()->getName() == 'users.edit'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.index')); ?>">Manage Books</a></li>
                <li <?php if(\Route::current()->getName() == 'users.create'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.create')); ?>">Create a Books</a></li>
                
                <li <?php if(\Route::current()->getName() == 'users.index' || \Route::current()->getName() == 'users.edit'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.index')); ?>">Manage Categories</a></li>
                <li <?php if(\Route::current()->getName() == 'users.create'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.create')); ?>">Create a Category</a></li>
                
                <li <?php if(\Route::current()->getName() == 'users.index' || \Route::current()->getName() == 'users.edit'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.index')); ?>">Manage Authors</a></li>
                <li <?php if(\Route::current()->getName() == 'users.create'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.create')); ?>">Create an Author</a></li>
                
                <li <?php if(\Route::current()->getName() == 'users.index' || \Route::current()->getName() == 'users.edit'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.index')); ?>">Manage Publishers</a></li>
                <li <?php if(\Route::current()->getName() == 'users.create'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.create')); ?>">Create a Publisher</a></li>
            </ul>
        </li>
    <?php endif; ?>

    

    <?php if(auth()->user()->is_an_admin()): ?>
        <li class="nav-item with-sub <?php if(request()->routeIs('users*')): ?> active show <?php endif; ?>">
            <a href="" class="nav-link"><i data-feather="dollar-sign"></i> <span>Funding Sources</span></a>
            <ul>
                <li <?php if(\Route::current()->getName() == 'users.index' || \Route::current()->getName() == 'users.edit'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.index')); ?>">Manage Agencies</a></li>
                <li <?php if(\Route::current()->getName() == 'users.create'): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('users.create')); ?>">Create an Agency</a></li>
            </ul>
        </li>
    <?php endif; ?>

</ul>
<?php /**PATH C:\xampp\htdocs\dfa-bis\resources\views/admin/layouts/sidebar-menu.blade.php ENDPATH**/ ?>