@php
	$footer = \App\Models\Page::where('slug', 'footer')->first();
@endphp


{!! $footer->contents !!}
<style>
	{!! $footer->styles !!}
</style>


{{-- <!-- Cookie
============================================= -->
<div class="alert text-center cookiealert" role="alert">
	<strong>Do you like cookies?</strong> &#x1F36A; We use cookies to ensure you get the best experience on our website. <a href="#" target="_blank">Learn more</a>
	<button type="button" class="btn btn-primary btn-sm acceptcookies px-3" aria-label="Close">
		I agree
	</button>
</div><!-- #cookie end --> --}}