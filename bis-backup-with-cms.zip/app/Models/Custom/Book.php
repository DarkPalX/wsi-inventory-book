<?php

namespace App\Models\Custom;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Book extends Model
{
    use HasFactory, SoftDeletes;
    
    protected $table = 'books';
    protected $fillable = ['title', 
                            'subtitle', 
                            'edition', 
                            'isbn', 
                            'publication_date', 
                            'copyright', 
                            'publisher_id', 
                            'format', 
                            'paper_height', 
                            'paper_width', 
                            'cover_height', 
                            'cover_width', 
                            'pages', 
                            'color', 
                            'category_id', 
                            'author_id', 
                            'sku', 
                            'file_url', 
                            'total_cost', 
                            'editor', 
                            'researcher', 
                            'writer', 
                            'graphic_designer', 
                            'layout_designer', 
                            'photographer', 
                            'markup_fee', 
                            'agency_id'];

                            

    public function categories()
    {
        return $this->hasMany(BookCategory::class)->orderBy('order');
    }
}
